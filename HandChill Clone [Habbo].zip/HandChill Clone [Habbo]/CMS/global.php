<?php

###############################################################################
#                            www.HabMusic.de Clone                            #
#                              Powered by Habbink                             #
#                                                                             #
#               Developer by Yılmaz EV (Discord: Hugoyin#7116)                #
###############################################################################

include ('library/sessions/config.php');


if (isset($_GET['language'])) {
  setcookie($_GET['language'], time()+3600); 
    include ('library/sessions/language/'.$_GET['language'].'.php');
}

if (empty($_GET['language'])) {
  if (isset($_COOKIE["idioma"])) {
    include ('library/sessions/language/'.$_COOKIE["idioma"].'.php');
  } else {
    include ('library/sessions/language/'.$language.'.php');
  }
}

$resultado = $link->query("SELECT * FROM config WHERE id = 1");
  while($row = mysqli_fetch_array($resultado))
  {
  $url = $row['url'];
  $title = $row['title'];
  $description = $row['description'];
  $keywords = $row['keywords'];
  $login_op = $row['login'];
  $register_op = $row['register'];
  $yilmazev = $row['yilmazev'];
  $theme = $row['theme'];
}

$consulta = "SELECT * FROM users WHERE username = '".$username."' LIMIT 1";
$filas = $link->query($consulta);
$columnas = mysqli_fetch_assoc($filas);
$rank = $columnas['rank'];
$ID = $columnas['ID'];

 $resultado = $link->query("SELECT * FROM ranks WHERE id = 9");
  while($row=mysqli_fetch_array($resultado))
  {
$rango9 = "9";
$rango_9 = $row['name'];
  } 

 $resultado = $link->query("SELECT * FROM ranks WHERE id = 8");
  while($row=mysqli_fetch_array($resultado))
  {
$rango8 = "8";
$rango_8 = $row['name'];
  } 

 $resultado = $link->query("SELECT * FROM ranks WHERE id = 7");
  while($row=mysqli_fetch_array($resultado))
  {
$rango7 = "7";
$rango_7 = $row['name'];
  } 
  
  $resultado = $link->query("SELECT * FROM ranks WHERE id = 6");
  while($row=mysqli_fetch_array($resultado))
  {
$rango6 = "6";
$rango_6 = $row['name'];
  }

   $resultado = $link->query("SELECT * FROM ranks WHERE id = 5");
  while($row=mysqli_fetch_array($resultado))
  {
$rango5 = "5";
$rango_5 = $row['name'];
  }

   $resultado = $link->query("SELECT * FROM ranks WHERE id = 4");
  while($row=mysqli_fetch_array($resultado))
  {
$rango4 = "4";
$rango_4 = $row['name'];
  }

   $resultado = $link->query("SELECT * FROM ranks WHERE id = 3");
  while($row=mysqli_fetch_array($resultado))
  {
$rango3 = "3";
$rango_3 = $row['name'];
  }

$head = "<!DOCTYPE html>
<html>
<head>
  <meta http-equiv='Content-Type' content='text/html; charset=euc-jp'>
  <meta name='viewport' content='width=device-width, initial-scale=1'>

  <!-- Search Engine -->
  <meta name='description' content='$description'>
  <meta name='image' content='$url/library/img/og-image.png?$lang[version]'>
  <meta name='keywords' content='$keywords' />

  <!-- Schema.org for Google -->
  <meta itemprop='name' content='$title'>
  <meta itemprop='description' content='$description'>
  <meta itemprop='image' content='$url/library/img/og-image.png?$lang[version]'>

  <!-- Twitter -->
  <meta name='twitter:card' content='summary'>
  <meta name='twitter:title' content='$title'>
  <meta name='twitter:description' content='$description'>
  <meta name='twitter:site' content='@$lang[twitter] '>
  <meta name='twitter:creator' content='@$lang[twitter] '>
  <meta name='twitter:image:src' content='$url/library/img/og-image.png?$lang[version]'>

  <!-- Open Graph general (Facebook, Pinterest & Google+) -->
  <meta name='og:title' content='$title'>
  <meta name='og:description' content='$description'>
  <meta name='og:image' content='$url/library/img/og-image.png?$lang[version]'>
  <meta name='og:url' content='$url'>
  <meta name='og:site_name' content='$title'>
  <meta name='og:locale' content='$lang[location] '>
  <meta name='og:type' content='website'>

  <!-- Theme -->
  <link rel='icon' href='$url/favicon.ico?$lang[version]'>
  <link rel='stylesheet' href='$url/library/css/app.css?$lang[version]'>
  <script src='https:/kit.fontawesome.com/8cae2c4f79.js' crossorigin='anonymous'></script>
  
  <title>$title - $description</title>
</head>
";
  
?>