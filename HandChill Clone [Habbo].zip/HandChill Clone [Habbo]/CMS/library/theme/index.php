<?php if("$yilmazev" == "https://github.com/yilmazev"){ ?> 
        <div class="featured-articles">
          <div id="handchill">
            <div class="icon"></div>
            <div class="titre"><?php echo "$title" ?>
              <div class="desc"><?php echo $lang["index fansite description"]; ?> <?php echo "$title" ?>.</div>
            </div>
          </div>
          <div class="main--news">
            <?php $resultado = $link->query("SELECT * FROM news WHERE category = 'Fansite'  ORDER BY id DESC limit 1000"); while($row = mysqli_fetch_array($resultado)) { ?>
			<a href="/article?read=<?php echo "$row[id]"; ?>">
              <div class="home-news-box">
                <div class="news-image" style="background-image: url(<?php echo "$row[featured_image]"; ?>);">
                </div>
                <h2><?php echo "$row[title]"; ?></h2>
              </div>
            </a>
			<?php } ?>
          </div>
        </div>
        <div class="featured-articles">
          <div id="habbo">
            <div class="icon"></div>
            <div class="titre"><?php echo $lang["hotel name"]; ?> Hotel
              <div class="desc"><?php echo $lang["index hotel description"]; ?> <?php echo $lang["hotel name"]; ?>.</div>
            </div>
          </div>
          <div class="main--news">
            <?php $resultado = $link->query("SELECT * FROM news WHERE category = 'Hotel'  ORDER BY id DESC limit 1000"); while($row = mysqli_fetch_array($resultado)) { ?>
			<a href="/article?read=<?php echo "$row[id]"; ?>">
              <div class="home-news-box">
                <div class="news-image" style="background-image: url(<?php echo "$row[featured_image]"; ?>);">
                </div>
                <h2><?php echo "$row[title]"; ?></h2>
              </div>
            </a>
			<?php } ?>
          </div>
        </div>
      </main>
    </div>
<?php } ?>