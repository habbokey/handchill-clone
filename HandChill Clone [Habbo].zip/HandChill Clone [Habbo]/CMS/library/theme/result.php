<?php if("$yilmazev" == "https://github.com/yilmazev"){ ?> 
        <?php 
        $word = $_GET["word"];
        if($word) {
        ?>
		<div class="featured-articles">
          <div class="main--news">
            <?php $resultado = $link->query("SELECT * FROM news WHERE title LIKE '%$word%' ORDER BY id DESC limit 999"); while($row = mysqli_fetch_array($resultado)) { ?>
			<a href="/article?read=<?php echo "$row[id]"; ?>">
              <div class="home-news-box">
                <div class="news-image" style="background-image: url(<?php echo "$row[featured_image]"; ?>);">
                </div>
                <h2><?php echo "$row[title]"; ?></h2>
              </div>
            </a>
			<?php } ?>
          </div>
        </div>
      </main>
    </div>
<?php } } ?>