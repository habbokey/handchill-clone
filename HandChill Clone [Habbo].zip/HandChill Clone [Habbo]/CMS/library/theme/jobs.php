<?php if("$yilmazev" == "https://github.com/yilmazev"){ ?> 
        <div class="featured-articles">
          <div id="jobs">
            <div class="icon"></div>
            <div class="titre"><?php echo $lang["jobs title"]; ?>
              <div class="desc"><?php echo $lang["jobs description"]; ?></div>
            </div>
          </div>
        </div>
        <div id="page">
          <p><?php echo $lang["jobs box description"]; ?></p>
          <h3><?php echo $lang["jobs box title"]; ?></h3>
          <p><?php echo $lang["jobs box req"]; ?></p>
          <p><b><u><?php echo $lang["jobs box mail"]; ?></u></b>&nbsp;<?php echo $lang["mail"]; ?></p>
        </div>
      </main>
    </div>
<?php } ?>