<?php if("$yilmazev" == "https://github.com/yilmazev"){ ?> 
        <style>
        .succes {
		  background-color: #06e0aa;
		  border-radius: 3px;
		  padding: 10px 15px;
		  font-size: 14px;
		  margin-bottom: 20px;
        }
		  
        .register-button {
		  background-color: #1eae8a;
        }
        </style>
        <div class="mid">
		  <div class="succes"><?php echo $lang["login congratulations"]; ?></div>
          <form method="post" action="<?php echo "$url";?>/library/sessions/login.php" name="requestForm" class="form">
		    <label for="register_username" class="title-register"><?php echo $lang["login username"]; ?></label>
            <input required type="text" maxlength="25" id="username" name="username" class="textfield">
  
			<label for="register_password" class="title-register"><?php echo $lang["login password"]; ?></label>
            <input required type="password" maxlength="25" id="password" name="password" class="textfield">

			<input class="register-button" type="submit" class="submit" value="<?php echo $lang["login button"]; ?>">
          </form>
        </div>
      </main>
    </div>
<?php } ?>