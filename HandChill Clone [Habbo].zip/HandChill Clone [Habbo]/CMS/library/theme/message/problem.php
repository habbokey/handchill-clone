<?php if("$yilmazev" == "https://github.com/yilmazev"){ ?> 
        <style>
        .error {
		  background-color: #e24a70;
		  border-radius: 3px;
		  padding: 10px 15px;
		  font-size: 14px;
		  margin-bottom: 20px;
        }
        </style>
        <div class="mid">
          <div class="login-titre">
            <div class="titre">
              <font style="vertical-align: inherit;"><?php echo $lang["register title"]; ?></font>
            </div>
          </div>
		  <div class="error"><?php echo $lang["register question error"]; ?></div>
          <form method="post" action="<?php echo "$url";?>/library/sessions/register.php" name="requestForm">
		    <?php $min_number = 1; $max_number = 15; $random_number1 = mt_rand($min_number, $max_number); $random_number2 = mt_rand($min_number, $max_number); ?>
            <label for="register_username" class="title-register"><?php echo $lang["register username"]; ?></label>
            <input required type="text" maxlength="25" id="username" name="username" class="textfield">
            
			<label for="register_email" class="title-register"><?php echo $lang["register mail"]; ?></label>
            <input required type="text" maxlength="50" id="email" name="email" class="textfield">
            
			<label for="register_password" class="title-register"><?php echo $lang["register password"]; ?></label>
            <div class="disclaimer"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;<?php echo $lang["hotel name"]; ?> <?php echo $lang["register password warning"]; ?></div>
            <input required type="password" maxlength="25" id="password" name="password" class="textfield">
            
			<label for="register_password_confirmation" class="title-register"><?php echo $lang["register security"]; ?></label>
            <input required type="text" placeholder="<?php echo $random_number1; ?> + <?php echo $random_number2; ?> <?php echo $lang["register security question"]; ?>" maxlength="2" name="captchaResult" class="textfield">
			<input hidden name="firstNumber" value="<?php echo $random_number1; ?>" />
			<input hidden name="secondNumber" value="<?php echo $random_number2; ?>" />
            
			<input class="register-button" type="submit" class="submit" value="<?php echo $lang["register button"]; ?>">
          </form>
        </div>
      </main>
    </div>
<?php } ?>