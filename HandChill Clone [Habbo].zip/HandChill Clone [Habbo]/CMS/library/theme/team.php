<?php if("$yilmazev" == "https://github.com/yilmazev"){ ?> 
       <?php
       $resultado = $link->query("SELECT * FROM ranks WHERE id = 2");
       while($row = mysqli_fetch_array($resultado))
       {
		   $idrank3 = $row['id'];
       }
       $resultado = $link->query("SELECT * FROM ranks WHERE id = 3");
       while($row = mysqli_fetch_array($resultado))
       {
		   $idrank3 = $row['id'];
       }
       $resultado = $link->query("SELECT * FROM ranks WHERE id = 4");
       while($row = mysqli_fetch_array($resultado))
       {
		   $idrank4 = $row['id'];
       }
       $resultado = $link->query("SELECT * FROM ranks WHERE id = 5");
       while($row = mysqli_fetch_array($resultado))
       {
		   $idrank5 = $row['id'];
       }
       $resultado = $link->query("SELECT * FROM ranks WHERE id = 6");
       while($row = mysqli_fetch_array($resultado))
       {
		   $idrank6 = $row['id'];
       }
       $resultado = $link->query("SELECT * FROM ranks WHERE id = 7");
       while($row = mysqli_fetch_array($resultado))
       {
		   $idrank7 = $row['id'];
       }
       $resultado = $link->query("SELECT * FROM ranks WHERE id = 8");
       while($row = mysqli_fetch_array($resultado))
       {
		   $idrank8 = $row['id'];
       }
       ?>
	   <style>
	   #card--profil:hover .card--avatar {
		   opacity: 1;
	   }
	   </style>
       <div class="featured-articles">
          <div id="team">
            <div class="icon"></div>
            <div class="titre"><?php echo $lang["team title"]; ?>
              <div class="desc"><?php echo "$title";?><?php echo $lang["team description"]; ?></div>
            </div>
          </div>
        </div>
        <div id="page">
          <h3>» <?php echo $lang["team rank8 and rank7"]; ?></h3>
          <div id="card--roles">
            <?php $resultado = $link->query("SELECT * FROM users WHERE rank = 8"); while($row = mysqli_fetch_array($resultado)) { ?>
			<div id="card--profil">
              <div class="card--avatar" style="background-image: url(<?php echo $lang["hotel url"]; ?>/habbo-imaging/avatarimage?user=<?php echo $row['username']; ?>&direction=2&head_direction=3&gesture=sml&action=wlk,wav&size=l)"></div>
              <div class="card--nick"><a><?php echo $row['username']; ?></a></div>
            </div>
            <?php } ?>
			<?php $resultado = $link->query("SELECT * FROM users WHERE rank = 7"); while($row = mysqli_fetch_array($resultado)) { ?>
			<div id="card--profil">
              <div class="card--avatar" style="background-image: url(<?php echo $lang["hotel url"]; ?>/habbo-imaging/avatarimage?user=<?php echo $row['username']; ?>&direction=2&head_direction=3&gesture=sml&action=wlk,wav&size=l)"></div>
              <div class="card--nick"><a><?php echo $row['username']; ?></a></div>
            </div>
            <?php } ?>
          </div>
		  <h3>» <?php echo $lang["team rank6"]; ?></h3>
          <div id="card--roles">
            <?php $resultado = $link->query("SELECT * FROM users WHERE rank = 6"); while($row = mysqli_fetch_array($resultado)) { ?>
			<div id="card--profil">
              <div class="card--avatar" style="background-image: url(<?php echo $lang["hotel url"]; ?>/habbo-imaging/avatarimage?user=<?php echo $row['username']; ?>&direction=2&head_direction=3&gesture=sml&action=wlk,wav&size=l)"></div>
              <div class="card--nick"><a><?php echo $row['username']; ?></a></div>
            </div>
            <?php } ?>
          </div>
		  <h3>» <?php echo $lang["team rank5"]; ?></h3>
          <div id="card--roles">
            <?php $resultado = $link->query("SELECT * FROM users WHERE rank = 5"); while($row = mysqli_fetch_array($resultado)) { ?>
			<div id="card--profil">
              <div class="card--avatar" style="background-image: url(<?php echo $lang["hotel url"]; ?>/habbo-imaging/avatarimage?user=<?php echo $row['username']; ?>&direction=2&head_direction=3&gesture=sml&action=wlk,wav&size=l)"></div>
              <div class="card--nick"><a><?php echo $row['username']; ?></a></div>
            </div>
            <?php } ?>
          </div>
		  <h3>» <?php echo $lang["team rank4 and rank3"]; ?></h3>
          <div id="card--roles">
            <?php $resultado = $link->query("SELECT * FROM users WHERE rank = 4"); while($row = mysqli_fetch_array($resultado)) { ?>
			<div id="card--profil">
              <div class="card--avatar" style="background-image: url(<?php echo $lang["hotel url"]; ?>/habbo-imaging/avatarimage?user=<?php echo $row['username']; ?>&direction=2&head_direction=3&gesture=sml&action=wlk,wav&size=l)"></div>
              <div class="card--nick"><a><?php echo $row['username']; ?></a></div>
            </div>
            <?php } ?>
			<?php $resultado = $link->query("SELECT * FROM users WHERE rank = 3"); while($row = mysqli_fetch_array($resultado)) { ?>
			<div id="card--profil">
              <div class="card--avatar" style="background-image: url(<?php echo $lang["hotel url"]; ?>/habbo-imaging/avatarimage?user=<?php echo $row['username']; ?>&direction=2&head_direction=3&gesture=sml&action=wlk,wav&size=l)"></div>
              <div class="card--nick"><a><?php echo $row['username']; ?></a></div>
            </div>
            <?php } ?>
          </div>
		  <h3>» <?php echo $lang["team rank2"]; ?></h3>
          <div id="card--roles">
            <?php $resultado = $link->query("SELECT * FROM users WHERE rank = 2"); while($row = mysqli_fetch_array($resultado)) { ?>
			<div id="card--profil">
              <div class="card--avatar" style="background-image: url(<?php echo $lang["hotel url"]; ?>/habbo-imaging/avatarimage?user=<?php echo $row['username']; ?>&direction=2&head_direction=3&gesture=sml&action=wlk,wav&size=l)"></div>
              <div class="card--nick"><a><?php echo $row['username']; ?></a></div>
            </div>
            <?php } ?>
          </div>
        </div>
      </main>
    </div>
<?php } ?>