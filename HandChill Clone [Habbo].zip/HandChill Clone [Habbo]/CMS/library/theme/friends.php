<?php if("$yilmazev" == "https://github.com/yilmazev"){ ?> 
        <div class="featured-articles">
          <div id="friends">
            <div class="icon"></div>
            <div class="titre"><?php echo $lang["friends title"]; ?>
              <div class="desc"><?php echo "$title";?> <?php echo $lang["friends description"]; ?></div>
            </div>
          </div>
        </div>
        <div id="page">
          <p><b><?php echo $lang["friends box title"]; ?></b></p>
          <p><?php echo $lang["friends box description1"]; ?> <b><?php echo $lang["mail"]; ?></b> <?php echo $lang["friends box description2"]; ?> <b><?php echo $lang["friends box topic"]; ?></b> <?php echo $lang["friends box description3"]; ?></p>
        </div>
      </main>
    </div>
<?php } ?>