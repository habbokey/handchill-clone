<?php

###############################################################################
#                            www.HandChill.fr Clone                           #
#                              Powered by Habbink                             #
#                                                                             #
#               Developer by Yilmaz EV (Discord: Hugoyin#7116)                #
###############################################################################

require ('global.php');

include "library/theme/header.php";
include "library/theme/hotel.php";
include "library/theme/footer.php";

?>