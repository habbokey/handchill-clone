<?php

###############################################################################
#                            www.HandChill.fr Clone                           #
#                              Powered by Habbink                             #
#                                                                             #
#               Developer by Yilmaz EV (Discord: Hugoyin#7116)                #
###############################################################################

$lang = array(

// Others
	"hotel name" => "Habbo",
	"hotel url" => "Habbo.com",
	"location" => "en-US",
	"twitter" => "habbo",
	"version" => "1.0.0",
	"mail" => "example@example.com",
	
// 404 & 500 Error Page
	"error name 404" => "404",
	"error name 500" => "500",
	"error title" => "Page not found",
	
// Menu
	"home" => "Home",
	"articles" => "News",
	"search" => "Search in news...",
	"button register" => "REGISTER",
	"button connect" => "LOGIN",
	
// Login
	"login hello" => "Hello",
	"login description" => "How nice to see you again!",
	"login username" => "Username",
	"login password" => "Password",
	"login button" => "Login",
	
// Login Error
	"login password error" => "You mistyped your password or such an account did not exist before.",
	"login congratulations" => "Congratulations, your account has been successfully created. You can log in now.",
	
// Register
	"register title" => "Create Free Account",
	"register username" => "Username",
	"register mail" => "Email Address",
	"register password" => "Password",
	"register password warning" => "Do not use the password you use at",
	"register security" => "Security Question",
	"register security question" => "What is the sum of",
	"register button" => "Register",
	
// Register Error
	"login mail error" => "The email address you typed is already in use by someone else.",
	"login question error" => "You got the security question wrong.",
	"login username error" => "The Username you wrote is already in use by someone else.",
	
// Index
	"index fansite description" => "Follow the news for",
	"index hotel description" => "Keep up to date with the latest gossip for",
	
// Articles
	"articles title" => "News",
	"articles description" => "Follow the last minute gossip.",
	
// Articles > Article
	"article by" => "by",
	"article write" => "Write something...",
	"article button" => "Submit",
	"article nologin text" => "You must be logged in to comment on this article.",
	"article nologin button" => "LOGIN",
	
// Fansite
	"fansite team" => "Our Team",
	"fansite friends" => "Friends",
	"fansite jobs" => "Jobs",
	
// Fansite > Team
	"team title" => "Our Team",
	"team description" => "'s volunteer employees are listed here.",
	"rank1" => "User",
	"rank2" => "Support",
	"rank3" => "Design Builder",
	"rank4" => "Wired Builder",
	"rank5" => "Reporter",
	"rank6" => "Moderator",
	"rank7" => "Developer",
	"rank8" => "Director",
	"team rank8 and rank7" => "Project Management",
	"team rank6" => "Moderators",
	"team rank5" => "Reporters",
	"team rank4 and rank3" => "Builders",
	"team rank2" => "Supports",
	
// Fansite > Friends
	"friends title" => "Friends",
	"friends description" => "partners are listed here.",
	"friends box title" => "Do you have a fan page too? Work with us.",
	"friends box description1" => "If you want to work with us, you are in the right place. To",
	"friends box description2" => "With the title",
	"friends box description3" => ", send us your fan page link, name and tagline. We will get back to you as soon as possible!",
	"friends box topic" => "Working with HandChill",
	
// Fansite > Jobs
	"jobs title" => "Jobs",
	"jobs description" => "You are in the right place to work with us!",
	"jobs box description" => "With her dedication to creating and editing quality content, she decides to approach hiring in her own way. Getting regular investment and unwavering motivation from our teams is one of our main concerns. Train and support our employees through a variety of activities to get the most out of each. To impose and encourage dialogue and mutual aid to maximize human relationship within our team. Diversify and inform our readers differently, thanks to keen analysis and leveraged synthesis capacities. Be proud every day to represent an elite generation where knowledge, entertainment and safety are in perfect harmony.",
	"jobs box title" => "Work with Us",
	"jobs box req" => "To work with us, send us a letter with your in-game name, Discord name, age, department you will be working in and why we should choose you.",
	"jobs box mail" => "Email address to send message to:",
	
// Footer
	"copyright" => "all rights reserved.",
	"developer" => "Hugoyin",
	"developer text" => "Edited by",
	"footer text1" => "is not endorsed, endorsed or sponsored by and is not affiliated with Habbo Hotel or its affiliates.",
	"footer text2" => "may use trademarks and other Habbo intellectual property permitted under the Habbo fansite policy.",
	
###########################################################################################################
	
// Admin Panel
	"panel rank1" => "Home",
	"panel rank5" => "Reporters",
	"panel rank5 news" => "News",
	"panel rank6" => "Moderators",
	"panel rank6 news" => "News",
	"panel rank6 comments" => "Comments",
	"panel rank7" => "Developer",
	"panel rank7 config" => "Config",
	"panel rank8" => "Director",
	"panel rank8 team" => "Team",
	"panel rank8 users" => "Users",
	"panel rank8 logs" => "Logs",
	"panel rank8 pages" => "Pages",
	"panel statics team" => "Team<br>Members",
	"panel statics news" => "Total<br>News",
	"panel statics members" => "Total<br>Members",
	"panel statics visits" => "Daily<br>Visits",
	
	
// Admin Panel > Home
	"panel home title" => "Latest User Details",
	"panel home id" => "ID",
	"panel home username" => "Username",
	"panel home mail" => "Email Address",
	"panel home date" => "Date of Registration",
	
###########################################################################################################
	
// Admin Panel > News
	"panel news title" => "News",
	"panel news details" => "Details",
	"panel news category" => "Category",
	"panel news date" => "Date",
	"panel news actions" => "Actions",
	"panel news by" => "by",
	"panel news button new" => "New",
	"panel news button edit" => "Edit",
	
// Admin Panel > News > Create
	"panel news create new" => "New",
	"panel news create author" => "Author",
	"panel news create title" => "Title",
	"panel news create content" => "Content",
	"panel news create featured image" => "Featured Image",
	"panel news create featured image warning1" => "After uploading the image to",
	"panel news create featured image warning2" => "write its address here.",
	"panel news create category" => "Category",
	"panel news create button" => "Publish",
	
// Admin Panel > News > Edit
	"panel news edit editing" => "Editing",
	"panel news edit author" => "Author",
	"panel news edit title" => "Title",
	"panel news edit content" => "Content",
	"panel news edit featured image" => "Featured Image",
	"panel news edit featured image warning1" => "After uploading the image to",
	"panel news edit featured image warning2" => "write its address here.",
	"panel news edit category" => "Category",
	"panel news edit button" => "Edit",
	
###########################################################################################################
	
// Admin Panel > Moderator > News
	"panel moderator news title" => "News",
	"panel moderator news article title" => "Title",
	"panel moderator news author" => "Author",
	"panel moderator news date" => "Date",
	"panel moderator news actions" => "Actions",
	"panel moderator news button" => "Remove",
	
// Admin Panel > Moderator > Comments
	"panel moderator comments title" => "Comments",
	"panel moderator comments username" => "Username",
	"panel moderator comments comment" => "Comment",
	"panel moderator comments actions" => "Actions",
	"panel moderator comments button" => "Remove",
	
###########################################################################################################
	
// Admin Panel > Developer > Config
	"panel developer config title" => "Config",
	"panel developer config url" => "Website URL",
	"panel developer config name" => "Website Name",
	"panel developer config description" => "Website Description",
	"panel developer config keywords" => "Keywords",
	"panel developer config button" => "Submit",
	
###########################################################################################################
	
// Admin Panel > Director > Team
	"panel director team new title" => "New Team Members",
	"panel director team members title" => "Team Members",
	"panel director team username" => "Username",
	"panel director team look" => "Look",
	"panel director team rank" => "Rank",
	"panel director team button" => "Submit",
	
###########################################################################################################
	
// Admin Panel > Director > Users
	"panel director users title" => "Users",
	"panel director users id" => "ID",
	"panel director users username" => "Username",
	"panel director users mail" => "Email Address",
	"panel director users date" => "Date of Registration",
	"panel director users actions" => "Actions",
	"panel director users button" => "Details",
	
// Admin Panel > Director > Users > Details
	"panel director users details title" => "'s Information",
	"panel director users details id" => "ID",
	"panel director users details username" => "Username",
	"panel director users details mail" => "Email Address",
	"panel director users details date" => "Date of Registration",
	"panel director users details rank" => "Rank",
	"panel director users details banned" => "Because this user has been banned, you cannot access their information.",
	
// Admin Panel > Director > Users > Details > Banned
	"panel director users details banned title" => "Banned User",
	"panel director users details banned username" => "Username",
	"panel director users details banned reason" => "Reason",
	"panel director users details banned end" => "Expiry Date of the Ban",
	"panel director users details banned button" => "Banned",
	
###########################################################################################################
	
// Admin Panel > Director > Logs
	"panel director logs title" => "Logs",
	"panel director logs username" => "Username",
	"panel director logs action" => "Transaction",
	"panel director logs date" => "Date",
	
// Admin panel> Director > Logs > Text
	"paneldirectorlogstextregister" => "create account",
	"paneldirectorlogstextlogin" => "sign in",
	"paneldirectorlogstextlogout" => "logout",
	"paneldirectorlogstextcomment" => "make comment a article",

// Admin panel> Director > Logs > Text (Team Members)
	"paneldirectorlogstextcreatearticle" => "create news",
	"paneldirectorlogstextcreatepage" => "create page",
	"paneldirectorlogstexteditarticle" => "editing article",
	"paneldirectorlogstexteditpage" => "editing page",
	"paneldirectorlogstextremovenews" => "remove article",
	"paneldirectorlogstextremovepages" => "remove page",
	"paneldirectorlogstextremovecomments" => "remove comments",
	"paneldirectorlogstextconfig" => "updated site settings",
	
###########################################################################################################
	
// Admin Panel > Director > Pages
	"panel director pages pages" => "Pages",
	"panel director pages new" => "New",
	"panel director pages title" => "Title",
	"panel director pages actions" => "Actions",
	"panel director pages button edit" => "Edit",
	"panel director pages button delete" => "Remove",

// Admin Panel > Director > Pages > New
	"panel director pages new new" => "New",
	"panel director pages new title" => "Title",
	"panel director pages new description" => "Description",
	"panel director pages new content" => "Content",
	"panel director pages new background" => "Background",
	"panel director pages new background warning1" => "After uploading the image to",
	"panel director pages new background warning2" => "write its address here.",
	"panel director pages new button" => "Publish",

// Admin Panel > Director > Pages > Edit
	"panel director pages edit editing" => "Editing",
	"panel director pages edit title" => "Title",
	"panel director pages edit description" => "Description",
	"panel director pages edit content" => "Content",
	"panel director pages edit background" => "Background",
	"panel director pages edit background warning1" => "After uploading the image to",
	"panel director pages edit background warning2" => "write its address here.",
	"panel director pages edit button" => "Edit",
	
###########################################################################################################
		
// Admin Panel > Successful
	"panel successful title" => "Notifications",
	"panel successful box title" => "Congratulations",
	"panel successful box description" => "Your transaction has been successfully completed!",
	
);
?>