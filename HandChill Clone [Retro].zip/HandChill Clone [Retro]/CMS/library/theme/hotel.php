<?php if("$yilmazev" == "https://github.com/yilmazev"){ ?> 
        <div id="GamePage">
          <div class="game" style="background-image: url('/library/img/habron.png');"></div>
          <div class="game--story">
            <?php $resultado = $link->query("SELECT * FROM pages ORDER BY id DESC limit 50"); while($row = mysqli_fetch_array($resultado)) { ?>
			<a href="/page?read=<?php echo "$row[id]"; ?>">
              <div id="page-box" style="background-image: url('<?php echo "$row[background]"; ?>');">
                <div id="deg">
                  <div><?php echo "$row[title]"; ?></div>
                </div>
              </div>
            </a>
			<?php } ?>
          </div>
        </div>
      </main>
    </div>
<?php } ?>