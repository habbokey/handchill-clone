<?php if("$yilmazev" == "https://github.com/yilmazev"){ echo "$head"; } else { echo "<title>License Error</title>"; }?>
<?php if("$yilmazev" == "https://github.com/yilmazev"){ ?>
<body>
  <div id="modal-login" class="animated fadeIn">
    <div id="box-connexion" class="bg-connexion">
      <div id="box-padding">
        <div class="icon">
          <i class="fa fa-times" aria-hidden="true" onclick="closeModal(modalLogin)"></i>
        </div>
        <div class="login-titre">
          <div class="titre"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $lang["login hello"]; ?></font></font></div>
          <?php echo $lang["login description"]; ?>
        </div>
        <form method="post" action="<?php echo "$url";?>/library/sessions/login.php" name="requestForm" class="form">
          <input required type="text" placeholder="<?php echo $lang["login username"]; ?>" maxlength="25" id="username" name="username" class="textfield">
          <input required type="password" placeholder="<?php echo $lang["login password"]; ?>" maxlength="25" id="password" name="password" class="textfield">
          <div class="submit">
            <input class="connect-button" type="submit" name="guardar" value="<?php echo $lang["login button"]; ?>">
          </div>
        </form>
      </div>
    </div>
  </div>
  <div class="container">
    <div class="container-background">
      <nav class="menu">
        <div class="sidebar__top">
          <a class="sidebar__logo" href="<?php echo "$url";?>/index"><img class="sidebar__pic" src="<?php echo "$url";?>/library/img/logo.svg?<?php echo $lang["version"]; ?>"></a>
          <a class="sidebar--logo--mobile" href="<?php echo "$url";?>/index"><img class="sidebar__pic" src="<?php echo "$url";?>/library/img/logo--mobile.svg?<?php echo $lang["version"]; ?>"></a>
        </div>
        <div class="sidebar__group">
          <div class="sidebar__menu">
            <a class="sidebar__item" href="<?php echo "$url";?>/index">
              <div class="sidebar__icon">
                <svg class="icon icon-game-play">
                  <image width="21" height="21" xlink:href="<?php echo "$url";?>/library/img/home.svg?<?php echo $lang["version"]; ?>">
                </svg>
              </div>
              <div class="sidebar__text"><?php echo $lang["home"]; ?></div>
            </a>
            <a class="sidebar__item" href="<?php echo "$url";?>/articles">
              <div class="sidebar__icon">
                <svg class="icon icon-game-play">
                  <image width="21" height="21" xlink:href="<?php echo "$url";?>/library/img/articles.svg?<?php echo $lang["version"]; ?>">
                </svg>
              </div>
              <div class="sidebar__text"><?php echo $lang["articles"]; ?></div>
            </a>
            <a class="sidebar__item" href="<?php echo "$url";?>/fansite">
              <div class="sidebar__icon">
                <svg class="icon icon-game-play">
                  <image width="21" height="21" xlink:href="<?php echo "$url";?>/library/img/popcorn.svg?<?php echo $lang["version"]; ?>">
                </svg>
              </div>
              <div class="sidebar__text"><?php echo "$title";?></div>
            </a>
            <a class="sidebar__item" href="<?php echo "$url";?>/hotel">
              <div class="sidebar__icon">
                <svg class="icon icon-game-play">
                  <image width="21" height="21" xlink:href="<?php echo "$url";?>/library/img/duck.svg?<?php echo $lang["version"]; ?>">
                </svg>
              </div>
              <div class="sidebar__text"><?php echo $lang["hotel name"]; ?> Hotel</div>
            </a>
          </div>
        </div>
      </nav>
      <main>
        <div class="usermenu">
          <form method="get" action="<?php echo "$url";?>/result.php">
            <span class="search--icon"><i class="fa fa-search" aria-hidden="true"></i></span>
            <input required type="text" class="search--input" placeholder="<?php echo $lang["search"]; ?>" name="word"/>
          </form>
          <?php if($_SESSION["logeado"] == "SI") { ?>
		  <div class="button-user" style="font-size: 13px;padding: 14px;cursor: default;"><i class="fa fa-certificate" aria-hidden="true"></i><strong>&nbsp;&nbsp;<?php echo "$username";?></strong></div>
		  <a href="<?php echo "$url";?>/logout" class="button-user"><i class="fa fa-sign-out" aria-hidden="true"></i></a>
		  <?php if("$rank" >= "5"){ ?>
		  <a href="<?php echo "$url";?>/panel/home" class="button-user"><i class="fas fa-lock" aria-hidden="true"></i></a>
		  <?php } } else { ?>
		  <a href="/register" class="button" style="float: right;background-color: #e24a70;"><strong><?php echo $lang["button register"]; ?></strong></a>
          <div class="button" onclick="openModal(modalLogin)" style="float: right;">
            <strong><?php echo $lang["button connect"]; ?></strong>
          </div>
		  <?php } ?>
        </div>
        <div class="borduremain"></div>
<?php } else { echo "<body><h1>License error</h1></body>"; }?>