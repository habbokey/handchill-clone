    <?php if("$yilmazev" == "https://github.com/yilmazev"){ ?>
    <!-- Scripts -->
    <script src="<?php echo "$url";?>/library/js/manifest.js?id=3c768977c2574a34506e"></script>
    <script src="<?php echo "$url";?>/library/js/vendor.js?id=01d8a1ecb0d280d2f685"></script>
    <script src="<?php echo "$url";?>/library/js/app.js?id=9dd430a3ab8b3409ab2a"></script>
	
	<div id="footer">
      <div id="parts" class="small">
        <a href="#" style="font-size: 23px; margin: 0 10px;" target="_blank"><i class="fa fa-twitter"></i></a>
        <a href="#" style="font-size: 23px; margin: 0 10px;" target="_blank"><i class="fa fa-instagram"></i></a>
        <a href="<?php echo "$yilmazev" ?>" style="font-size: 23px; margin: 0 10px;" target="_blank"><i class="fa fa-github"></i></a>
      </div>
      <div id="parts" class="big">
        <p><b>© <?php echo "$title";?>, <?php echo $lang["copyright"]; ?> <?php echo $lang["developer text"]; ?> <a style="color: #d94b70;" href="<?php echo "$yilmazev" ?>" target="_blank"><?php echo $lang["developer"]; ?>.</a></b></p>
        <p><?php echo "$url" ?>, <?php echo $lang["hotel name"]; ?> Hotel <?php echo $lang["footer text1"]; ?> <?php echo "$title";?>, <?php echo $lang["hotel name"]; ?> <?php echo $lang["footer text2"]; ?></p>
      </div>
    </div>
    <br>
  </div>
  <?php } else { echo ""; }?>
</body>
</html>
