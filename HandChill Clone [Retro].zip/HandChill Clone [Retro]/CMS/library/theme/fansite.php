<?php if("$yilmazev" == "https://github.com/yilmazev"){ ?> 
        <div id="GamePage">
          <div class="game" style="background-image: url('<?php echo "$url" ?>/library/img/handchill.png?<?php echo $lang["version"]; ?>');"></div>
          <div class="game--story">
            <a href="<?php echo "$url" ?>/team">
              <div id="page-box" style="background-image: url('<?php echo "$url" ?>/library/img/hncteam.png?<?php echo $lang["version"]; ?>');">
                <div id="deg">
                  <div><?php echo $lang["fansite team"]; ?></div>
                </div>
              </div>
            </a>
            <a href="<?php echo "$url" ?>/friends">
              <div id="page-box" style="background-image: url('<?php echo "$url" ?>/library/img/hncfriends.png?<?php echo $lang["version"]; ?>');">
                <div id="deg">
                  <div><?php echo $lang["fansite friends"]; ?></div>
                </div>
              </div>
            </a>
            <a href="<?php echo "$url" ?>/jobs">
              <div id="page-box" style="background-image: url('<?php echo "$url" ?>/library/img/hncjobs.png?<?php echo $lang["version"]; ?>');">
                <div id="deg">
                  <div><?php echo $lang["fansite jobs"]; ?></div>
                </div>
              </div>
            </a>
          </div>
        </div>
      </main>
    </div>
<?php } ?>