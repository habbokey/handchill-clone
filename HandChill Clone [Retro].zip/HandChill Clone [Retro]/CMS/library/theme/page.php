<?php if("$yilmazev" == "https://github.com/yilmazev"){ ?> 
        <style>.fr-dii.fr-fir { float: right; margin: 5px 0 5px 5px; max-width: calc(100% - 5px);} .fr-dii.fr-fil { float: left; margin: 5px 5px 5px 0; max-width: calc(100% - 5px);}</style>
		<?php $read = $_GET['read']; $consulta = "SELECT *FROM pages WHERE id = '".$read."' LIMIT 1"; $filas1 = $link->query($consulta); $columnas = mysqli_fetch_assoc($filas1); $page_id = $columnas['id']; ?>
        <title><?php echo "$title";?> - <?php echo $columnas['title']; ?></title>
		<?php if($_SESSION["logeado"] == "SI"){ $id_article = $columnas['id']; } ?>
		<div class="featured-articles">
		  <div id="habbo">
		    <div class="icon"></div>
		    <div class="titre"><?php echo $columnas['title']; ?>
			  <div class="desc"><?php echo $columnas['description']; ?></div>
		    </div>
		  </div>
		</div>
		<div id="page">
		  <?php echo $columnas['content']; ?>
		</div>
      </main>
    </div>
<?php } ?>