<?php if("$yilmazev" == "https://github.com/yilmazev"){ ?> 
       <?php $consulta = "SELECT * FROM users WHERE username = '".$username."' LIMIT 1"; $filas = $link->query($consulta); $columnas = mysqli_fetch_assoc($filas); $look = $columnas['look']; ?>
        <style>.fr-dii.fr-fir { float: right; margin: 5px 0 5px 5px; max-width: calc(100% - 5px);} .fr-dii.fr-fil { float: left; margin: 5px 5px 5px 0; max-width: calc(100% - 5px);}</style>
		<?php $read = $_GET['read']; $consulta = "SELECT *FROM news WHERE id = '".$read."' LIMIT 1"; $filas1 = $link->query($consulta); $columnas = mysqli_fetch_assoc($filas1); $article_id = $columnas['id']; ?>
        <title><?php echo "$title";?> - <?php echo $columnas['title']; ?></title>
		<?php if($_SESSION["logeado"] == "SI"){ $id_article = $columnas['id']; } ?>
		<article>
          <div class="title"><a><?php echo $columnas['title']; ?></a></div>
          <?php echo $lang["article by"]; ?> <a style="text-decoration: none;color: #FFFFFF;"><b><?php echo $columnas['author']; ?></b></a>
          <div class="spacer"></div>
          <div class="mid">
		     <?php echo $columnas['article']; ?>  
          </div>
        </article>
        <?php if($_SESSION["logeado"] == "SI"){ ?>
		<form action="" method="post" enctype="multipart/form-data" class="form-no-captions"> 
		  <div class="create--comment d-flex align-items-center">
		    <div class="d-flex align-items-center">
		      <div class="picture--author image--style" style="background-image: url(https://www.habbo.com/habbo-imaging/avatarimage?figure=<?php echo "$look" ?>&direction=3&head_direction=3&gesture=sml&action=wav,sit&size=n&&headonly=1);"></div>
		    </div>
		    <div class="based--textarea d-flex">
			  <input type="hidden" name="article_id" value="<?php echo $columnas['id'];?>"/>
			  <input type="hidden" name="username" value="<?php echo "$username";?>"/>
			  <input type="hidden" name="look" value="<?php echo "$look";?>"/>
		      <textarea name="comment" class="textfield--comment" placeholder="<?php echo $lang["article write"]; ?>"></textarea>
		      <input name="enviar" type="submit" value="<?php echo $lang["article button"]; ?>">
		    </div>
		  </div>
		</form>
		<?php
		error_reporting(0);
		
		$postarticle_id = $_POST['article_id'];
		$postusername = $_POST['username'];
		$postlook = $_POST['look'];

		if ("$article_id" == "$postarticle_id")
		{
		  if ("$look" == "$postlook") {
		  if ("$username" == "$postusername") 
		  {
	   	    $htmlremplazar1 = strip_tags($_POST['comment']);
	   	    if ($_POST['enviar'] && $_POST['article_id']) {
	   	    $enviar = "INSERT INTO comments (username,article_id,comment,look) values ('".$_POST['username']."','".$_POST['article_id']."','".$htmlremplazar1."','".$_POST['look']."')";

	   	    if ($link->query($enviar))
		    { 
	   	      $date_log = date("d.m.Y");
	   	      $action = "$lang[paneldirectorlogstextcomment]";
			  $enviar_log = "INSERT INTO logs (username,action,date) values ('".$username."','".$action."','".$date_log."')";
	   	      $resultado_log = $link->query($enviar_log);
	   	      header ("Location: ../article?read=$article_id");
			}
	   	  }
		}
		}
		}
        } else { ?>
		<div class="mid-content">
		  <div class="guest--comment">
            <div class="text"><?php echo $lang["article nologin text"]; ?></div>
            <div class="button" onclick="openModal(modalLogin)"><strong><?php echo $lang["article nologin button"]; ?></strong></div>
		  </div>
        </div>
		<?php } ?>
		<?php $query = $link->query('SELECT * FROM comments WHERE article_id = "'.$article_id.'" ORDER BY id DESC limit 100'); while($row = mysqli_fetch_array($query)) { ?>
		<div class="based--comment">
		  <div class="info--author d-flex align-items-center">
		    <div class="d-flex">
		      <div class="picture--author image--style" style="background-image: url(https://www.habbo.com/habbo-imaging/avatarimage?figure=<?php echo $row['look'];?>&direction=3&head_direction=3&gesture=sml&action=wav,sit&size=n&&headonly=1);"></div>
		    </div>
		    <div class="comment--date">
			  <h2 class="nick--author d-flex align-items-center">
                <a style="text-decoration: none;color: #FFFFFF;"><?php echo $row['username'];?></a>
			  </h2>
		    </div>
		  </div>
		  <div class="comment">
		    <p><?php $htmlremplazar = $row['comment']; echo strip_tags($htmlremplazar);?></p>
		  </div>
		</div>
		<?php } ?>
      </main>
    </div>
<?php } ?>